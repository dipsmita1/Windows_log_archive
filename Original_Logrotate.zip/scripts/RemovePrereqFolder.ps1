
try{
    $ErrorActionPreference = "Stop"
	
	$FolderForRemove = "c:\temp\logrotate"	
	
	if (Test-Path $FolderForRemove) {
	    Write-Host "OK! Folder $FolderForRemove is exists. Trying to remove it..."
		Remove-Item -path $FolderForRemove -Force -Recurse
    } else
	{
	    Write-Host "OK! Folder $FolderForRemove was removed before!"
		exit 0
    }
	
	if (Test-Path $FolderForRemove) {
	    Write-Host "ERROR! Folder $FolderForRemove was NOT removed!"
		exit 1
    } else
	{
    	Write-Host "OK! Folder $FolderForRemove was removed!" 
		exit 0
    }
	
}
Catch{
    $ErrorActionPreference = "Stop";
    Write-Host "Caught an exception";
    Write-Host $Error[0].Exception;
    [System.Environment]::Exit(1)
}
	
	



