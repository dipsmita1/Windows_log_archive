try {
  $ErrorActionPreference = "Stop";
  
  $source_path = "c:\temp\logrotate"
  $source_script_file_path = $source_path+"\scripts\LogArchive.ps1"
  $source_config_file_path = $source_path+"\config\configurationLogArchive.json"
  
  $destination_path = "C:\instance_files\SchedulerTasks"
  $destination_script_file_path = $destination_path+"\LogArchive.ps1"
  $destination_config_file_path = $destination_path+"\configurationLogArchive.json"
  
  if (Test-Path $destination_path) {
    Write-Host "OK! Folder $destination_path is exists!"
  } else
  {
    Write-Host "OK! Folder $destination_path does NOT exist!"
    Write-Host "Creating new Folder $destination_path..."
    New-Item -ItemType Directory -Force -Path $destination_path
  }

  if (Test-Path $destination_path) {
    Write-Host "OK! Folder $destination_path was created!"
  } else
  {
    Write-Host "ERROR! Folder $destination_path was NOT created!"
    exit 1
  }

  Write-Host "Trying to copy files..."
  Copy-Item -Path $source_script_file_path -Destination $destination_path -Force
  Copy-Item -Path $source_config_file_path -Destination $destination_path -Force
  
  if (Test-Path $destination_script_file_path) {
    Write-Host "OK! Script File LogArchive.ps1 was copied! Path: $destination_script_file_path!"
  } else
  {
    Write-Host "ERROR! Script File LogArchive.ps1 was NOT copied!"
    exit 1
  }
  
  if (Test-Path $destination_config_file_path) {
    Write-Host "OK! Config File configurationLogArchive.json was copied! Path: $destination_config_file_path!"
  } else
  {
    Write-Host "ERROR! Config File configurationLogArchive.json was NOT copied!"
    exit 1
  }
  

}
Catch{
    Write-Host "Caught an exception";
    Write-Host $Error[0].Exception;
    [System.Environment]::Exit(1)
}
