#This script bascially to keep only N number of required files in the directory and to moved out all other remainig to another archive folder
 try{
    $ErrorActionPreference = "Stop";
	
	######### Function to check and create the Arch Dir if not exist
	function Create_Archive_Directory
	{
		if( -Not (Test-Path -Path $archiv_dir))
		{
		Write-Host "Warning! Directory $archiv_dir does Not exist! Trying to create it..."
		New-Item -ItemType directory -Path $archiv_dir
		} else {
		Write-Host("OK! Directory $archiv_dir is exists!")
		}
	}
	
	#### Function to keep the required no of latest files and move the unwanted one to Archive folder ###
	function Keep_Logs_And_Move_Files([int]$No_files_to_keep)
	{
		Write-Host "Count of keep files: " $No_files_to_keep
		# Check and create Archive dir if not exist
		Create_Archive_Directory
		
		IF ($count_of_Files.Count -gt $No_files_to_keep){

			# Get the number of latest files
			$files_to_keep=Get-ChildItem -Path $source_dir | Where-Object { -not $_.PsIsContainer } | Sort-Object LastWriteTime -Descending | Select-Object -first $No_files_to_keep

			#compare exsting all files with files_to_keep to get  excluded_files that need to be moved out
			$exclude_files=Compare-Object -ReferenceObject ($files_to_keep | Sort-Object ) -DifferenceObject ($existing_files | Sort-Object)

			#Move exclude_files to archive
			foreach($i in $exclude_files){
			    Write-Host "Moving file $i..." 
				$i.InputObject | Move-Item -Destination $archiv_dir
			}

		} else{
			Write-Host "OK! Existing files are equal/lesser to the number required latest files!"
		
		}
	}
		
	function Archive_Keep_Latest_Remove_Old_Files([int]$numberOf_latest_Files)
	{
		IF($count_of_Files.Count -gt $numberOf_latest_Files){

			# Get the number of latest files
			$Latest_files_to_keep=Get-ChildItem -Path $archiv_dir | Where-Object { -not $_.PsIsContainer } | Sort-Object LastWriteTime -Descending | Select-Object -first $numberOf_latest_Files

			# compare exsting all files with files_to_keep to get  excluded_files that need to be moved out
			$exclude_files=Compare-Object -ReferenceObject ($Latest_files_to_keep | Sort-Object ) -DifferenceObject ($existing_files | Sort-Object)

			#Delete exclude_files from archive
			foreach($i in $exclude_files) {    
			    Write-Host "Removing file $i..." 
				$i.InputObject | Remove-Item -Path {Join-Path $archiv_dir $_ }
			}
		} else {
			Write-Host "OK! Count of exsiting archive files is equal/lesser to the number required latest files!"
		}
	}
	
	$ExtensionFile = "C:\instance_files\SchedulerTasks\configurationLogArchive.json"
	$jsondata = Get-Content -Raw -Path $ExtensionFile | ConvertFrom-Json
	
	$_ArrayLogFolders = $jsondata.array_logs
	$_CountFiles = $jsondata.count_files
	$_CountArchFiles = $jsondata.count_arch_files
		
	foreach ($logfolder in $_ArrayLogFolders){
			if (Test-Path $logfolder)
			{
   			    $source_dir = $logfolder
			    $archiv_dir = $jsondata.$logfolder
				
				Write-Host "Source Dir: $source_dir"
				Write-Host "Archive Dir: $archiv_dir"
				
				#get the count of files in the directory
				$count_of_files = Get-ChildItem $source_dir | Measure-Object | Select-Object Count
				$existing_files = ls $source_dir
					
				#Call the function to keep the latest in the log directory
				Keep_Logs_And_Move_Files $_CountFiles

				$count_of_files = Get-ChildItem $archiv_dir | Measure-Object | Select-Object Count
				$existing_files = ls $archiv_dir

				#Call the function with the no files that need to keep in the archive dir
				Archive_Keep_Latest_Remove_Old_Files $_CountArchFiles			  
						  
			  
			}
			else
			{
			  Write-Host "ERROR! Log Folder $logfolder was NOT found!"
			  exit 1
			}
	}

}
Catch{
    Write-Host "Caught an exception";
    Write-Host $Error[0].Exception;
    [System.Environment]::Exit(1)
}
