 try{
    $ErrorActionPreference = "Stop";

    $taskName = "AppLogRotation"
    $taskDescription = "Daily rotation application logs"

    $taskExists = Get-ScheduledTask $taskName -ErrorAction Ignore
    # $taskExists = Get-ScheduledTask | Where-Object {$_.TaskName -like $taskName }
    $User = "System"
	#$User = "Administrator"
	$LogArchiveScriptPath = "C:\instance_files\SchedulerTasks\LogArchive.ps1"
	

    if($taskExists) {
      Write-Host "OK. Task $taskName was created before."
      exit 0
    } else {
      Write-Host "WARNING! Task $taskName is NOT exist. Trying to create it..."
      $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument $LogArchiveScriptPath

      $trigger = New-ScheduledTaskTrigger -Daily -At "12:00am"
      Register-ScheduledTask -Action $action -Trigger $trigger -User $User -TaskName $taskName -Description $taskDescription -RunLevel Highest
    }

    $taskExists = Get-ScheduledTask $taskName -ErrorAction Ignore
	
    if($taskExists) {
      Write-Host "OK. Task $taskName was created."
      exit 0
    } else {
      Write-Host "ERROR! Task $taskName was NOT created."
      exit 1
    }

}
Catch{
    Write-Host "Caught an exception";
    Write-Host $Error[0].Exception;
    [System.Environment]::Exit(1)
}
