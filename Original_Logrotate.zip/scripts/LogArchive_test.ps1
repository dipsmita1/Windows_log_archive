 try{
    $ErrorActionPreference = "Stop";
	$CurrDate = Get-Date
	Add-Content c:\Temp\date.txt "$CurrDate"
}
Catch{
    Write-Host "Caught an exception";
    Write-Host $Error[0].Exception;
    [System.Environment]::Exit(1)
}
